# 星账云管家 · API 接口索引

> ⚠️ 本文件仅作为接口编号速查索引。接口参数、请求方法、响应结构等细节请通过 WebFetch 实时从 postar.cn 获取，确保与 Apifox 最新版本同步。

---

## 一、功能开通（6个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY001 | 功能开通（新增分账/归集产品） | https://www.postar.cn/xyf/doc/364081917e0 |
| XZY002 | 编辑上传付款凭证 | https://www.postar.cn/xyf/doc/364156075e0 |
| XZY003 | 编辑产品信息 | https://www.postar.cn/xyf/doc/364296676e0 |
| XZY004 | 修改生效状态 | https://www.postar.cn/xyf/doc/364453648e0 |
| XZY005 | 查询详情信息 | https://www.postar.cn/xyf/doc/364461971e0 |
| XZY006 | 产品开通审核通知（回调） | https://www.postar.cn/xyf/doc/367088020e0 |

## 二、公共接口（1个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY013 | 上传文件（base64/png） | https://www.postar.cn/xyf/doc/363755551e0 |

## 三、分账 — 交易（5个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY014 | 分账发起 | https://www.postar.cn/xyf/doc/403857068e0 |
| XZY015 | 分账结果回调 / 订单查询 | https://www.postar.cn/xyf/doc/364607681e0 |
| XZY016 | 分账结果回调 | https://www.postar.cn/xyf/doc/366323676e0 |
| XZY017 | 分账撤销退回 | https://www.postar.cn/xyf/doc/367370683e0 |
| XZY041 | 余额查询 | https://www.postar.cn/xyf/doc/377746665e0 |

## 四、分账 — 客户管理（9个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY018 | 新增客户 | https://www.postar.cn/xyf/doc/365780422e0 |
| XZY019 | 审核通知（回调） | https://www.postar.cn/xyf/doc/365780432e0 |
| XZY020 | 合作状态调整 | https://www.postar.cn/xyf/doc/365780424e0 |
| XZY021 | 查询分账客户信息 | https://www.postar.cn/xyf/doc/379092709e0 |
| XZY022 | 替换客户结算卡 | https://www.postar.cn/xyf/doc/365780428e0 |
| XZY023 | 编辑客户 | https://www.postar.cn/xyf/doc/365780426e0 |
| XZY043 | 分账授权申请（收单统一结算） | https://www.postar.cn/xyf/doc/378849194e0 |
| XZY044 | 批量分账授权申请（收单统一结算） | https://www.postar.cn/xyf/doc/380559940e0 |
| XZY-001 | 解约/重启签约 | https://www.postar.cn/xyf/doc/407610060e0 |

## 五、分账 — 回单（2个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY037 | 分账结算电子回单下载 | https://www.postar.cn/xyf/doc/371222429e0 |
| XZY039 | 分账合并入账电子回单下载 | https://www.postar.cn/xyf/doc/371225821e0 |

## 六、归集 — 开户/授权（6个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY037 | 归集授权申请（收单统一结算） | https://www.postar.cn/xyf/doc/367378001e0 |
| XZY025 | 审核通知（回调） | https://www.postar.cn/xyf/doc/366434705e0 |
| XZY026 | 合作状态调整 | https://www.postar.cn/xyf/doc/366434706e0 |
| XZY027 | 查询归集客户信息 | https://www.postar.cn/xyf/doc/366434707e0 |
| XZY028 | 替换结算卡 | https://www.postar.cn/xyf/doc/366434708e0 |
| XZY029 | 编辑信息 | https://www.postar.cn/xyf/doc/366434709e0 |

## 七、归集 — 交易（5个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY030 | 归集发起 | https://www.postar.cn/xyf/doc/403858128e0 |
| XZY030 | 归集发起（支持自定义服务费） | https://www.postar.cn/xyf/doc/366145868e0 |
| XZY031 | 归集结果查询 | https://www.postar.cn/xyf/doc/366147035e0 |
| XZY032 | 归集结果回调 | https://www.postar.cn/xyf/doc/366327114e0 |
| XZY033 | 归集撤销退回 | https://www.postar.cn/xyf/doc/367376340e0 |
| XZY042 | 余额查询 | https://www.postar.cn/xyf/doc/377752757e0 |

## 八、归集 — 回单（2个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY038 | 归集结算电子回单下载 | https://www.postar.cn/xyf/doc/371223696e0 |
| XZY040 | 归集合并入账电子回单下载 | https://www.postar.cn/xyf/doc/371226941e0 |

## 九、提现（4个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY035 | 提现订单查询 | https://www.postar.cn/xyf/doc/364606858e0 |
| XZY036 | 提现发起 | https://www.postar.cn/xyf/doc/403071557e0 |
| XZY040 | 提现电子回单下载 | https://www.postar.cn/xyf/doc/364658694e0 |
| XZY050 | 结算回调通知 | https://www.postar.cn/xyf/doc/370516118e0 |

## 十、账户（2个）

| 编号 | 用途 | 文档 URL |
|------|------|---------|
| XZY047 | 结算资金流水查询 | https://www.postar.cn/xyf/doc/383355742e0 |
| XZY049 | 结算卡资金流水查询 | https://www.postar.cn/xyf/doc/390944778e0 |

---

## 附录：业务总览

| 文档 | URL |
|------|-----|
| 星账云管家·业务总览（含分账/归集流程） | https://www.postar.cn/xyf/doc/7551893m0 |

---

## 服务器地址

| 环境 | URL |
|------|-----|
| 测试环境 | `https://xyf-server-test.postar.cn` |
| 正式环境 | `https://yyfsvxm.postar.cn` |

---

## 关键概念

- **600 商户代码**：星驿付分配给服务商的唯一商户标识
- **分账接收方**：接收分账资金的商户，需完成协议签署和审核
- **被归集方**：被归集资金的商户，需确认商户代码并完成签约
- **异步回调**：XZY006/XZY015/XZY016/XZY019/XZY025/XZY032/XZY050 均为异步回调

---

## 数据统计

| 模块 | 接口数 |
|------|-------|
| 功能开通 | 6 |
| 公共接口 | 1 |
| 分账-交易 | 5 |
| 分账-客户管理 | 9 |
| 分账-回单 | 2 |
| 归集-开户/授权 | 6 |
| 归集-交易 | 5 |
| 归集-回单 | 2 |
| 提现 | 4 |
| 账户 | 2 |
| **合计** | **42** |

---

## 维护说明

- 新增接口时在此表添加编号和对应的 postar.cn URL
- 接口参数变更时**无需修改本文件**——SKILL.md 规则已要求实时从线上拉取
